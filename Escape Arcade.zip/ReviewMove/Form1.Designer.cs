﻿namespace ReviewMove
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Box = new System.Windows.Forms.PictureBox();
            this.MatchDoor = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.SimonDoor = new System.Windows.Forms.PictureBox();
            this.PuzzelDoor = new System.Windows.Forms.PictureBox();
            this.ExitDoor = new System.Windows.Forms.PictureBox();
            this.timeremain = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatchDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimonDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PuzzelDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExitDoor)).BeginInit();
            this.SuspendLayout();
            // 
            // Box
            // 
            this.Box.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Box.Location = new System.Drawing.Point(318, 163);
            this.Box.Name = "Box";
            this.Box.Size = new System.Drawing.Size(45, 45);
            this.Box.TabIndex = 0;
            this.Box.TabStop = false;
            // 
            // MatchDoor
            // 
            this.MatchDoor.BackColor = System.Drawing.Color.White;
            this.MatchDoor.Image = ((System.Drawing.Image)(resources.GetObject("MatchDoor.Image")));
            this.MatchDoor.Location = new System.Drawing.Point(12, 14);
            this.MatchDoor.Name = "MatchDoor";
            this.MatchDoor.Size = new System.Drawing.Size(80, 125);
            this.MatchDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.MatchDoor.TabIndex = 1;
            this.MatchDoor.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(236, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 41);
            this.label1.TabIndex = 3;
            this.label1.Text = "Escape Room";
            // 
            // SimonDoor
            // 
            this.SimonDoor.BackColor = System.Drawing.Color.White;
            this.SimonDoor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SimonDoor.BackgroundImage")));
            this.SimonDoor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.SimonDoor.Image = ((System.Drawing.Image)(resources.GetObject("SimonDoor.Image")));
            this.SimonDoor.Location = new System.Drawing.Point(593, 14);
            this.SimonDoor.Name = "SimonDoor";
            this.SimonDoor.Size = new System.Drawing.Size(77, 125);
            this.SimonDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.SimonDoor.TabIndex = 5;
            this.SimonDoor.TabStop = false;
            this.SimonDoor.Visible = false;
            this.SimonDoor.Click += new System.EventHandler(this.SimonDoor_Click);
            // 
            // PuzzelDoor
            // 
            this.PuzzelDoor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PuzzelDoor.BackgroundImage")));
            this.PuzzelDoor.Image = ((System.Drawing.Image)(resources.GetObject("PuzzelDoor.Image")));
            this.PuzzelDoor.Location = new System.Drawing.Point(12, 225);
            this.PuzzelDoor.Name = "PuzzelDoor";
            this.PuzzelDoor.Size = new System.Drawing.Size(80, 125);
            this.PuzzelDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PuzzelDoor.TabIndex = 6;
            this.PuzzelDoor.TabStop = false;
            // 
            // ExitDoor
            // 
            this.ExitDoor.Image = ((System.Drawing.Image)(resources.GetObject("ExitDoor.Image")));
            this.ExitDoor.Location = new System.Drawing.Point(522, 186);
            this.ExitDoor.Name = "ExitDoor";
            this.ExitDoor.Size = new System.Drawing.Size(158, 164);
            this.ExitDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ExitDoor.TabIndex = 8;
            this.ExitDoor.TabStop = false;
            // 
            // timeremain
            // 
            this.timeremain.AutoSize = true;
            this.timeremain.Location = new System.Drawing.Point(213, 63);
            this.timeremain.Name = "timeremain";
            this.timeremain.Size = new System.Drawing.Size(124, 20);
            this.timeremain.TabIndex = 9;
            this.timeremain.Text = "Time Remaining: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(682, 353);
            this.Controls.Add(this.timeremain);
            this.Controls.Add(this.ExitDoor);
            this.Controls.Add(this.PuzzelDoor);
            this.Controls.Add(this.SimonDoor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MatchDoor);
            this.Controls.Add(this.Box);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.Box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatchDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SimonDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PuzzelDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExitDoor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox Box;
        private PictureBox MatchDoor;
        private System.Windows.Forms.Timer timer1;
        private Label label1;
        private PictureBox SimonDoor;
        private PictureBox PuzzelDoor;
        private PictureBox ExitDoor;
        private Label timeremain;
    }
}