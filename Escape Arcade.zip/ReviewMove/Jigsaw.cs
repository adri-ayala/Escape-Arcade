﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReviewMove
{
    public partial class Jigsaw : Form
    {
        int[] index = { 0, 0, 0, 0, 0, 0, 0, 0, 0 }; // array for state of gameboard
        int[] spaces = { 1, 2, 3, 4, 5, 6, 7, 8, 9 }; // array for winstate
        int select = 0;

        public Jigsaw()
        {
            InitializeComponent();
        }

        private void Jigsaw_Load(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (select != 0)//checks if puzzle piece has been selected, then places piece
            {
                index[0] = select;
                getPic(button1, select);
                select = 0;

                checkWin();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {
                index[1] = select;

                getPic(button2, select);
                select = 0;

                checkWin();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[2] = select;

                getPic(button3, select);
                select = 0;

                checkWin();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[3] = select;

                getPic(button4, select);
                select = 0;

                checkWin();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[4] = select;

                getPic(button5, select);
                select = 0;

                checkWin();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[5] = select;

                getPic(button6, select);
                select = 0;

                checkWin();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[6] = select;

                getPic(button7, select);
                select = 0;

                checkWin();
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[7] = select;

                getPic(button8, select);
                select = 0;

                checkWin();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (select != 0)
            {


                index[8] = select;

                getPic(button9, select);
                select = 0;


                checkWin();
            }
        }



 

        private void checkWin()
        {
            if (index[0] == spaces[0] && index[1] == spaces[1] && index[2] == spaces[2] && index[3] == spaces[3] && index[4] == spaces[4] && index[5] == spaces[5] && index[6] == spaces[6] && index[7] == spaces[7] && index[8] == spaces[8])
            {
                MessageBox.Show("You Win!");
                Form1 f1 = new Form1();

                f1.Show();
                this.Hide();

            }



        }
        private void resetBoard()
        {
            select = 0;
            Array.Clear(
                array: index,
                index: 0,
                length: index.Length);
            button1.BackgroundImage = null;
            button2.BackgroundImage = null;
            button3.BackgroundImage = null;
            button4.BackgroundImage = null;
            button5.BackgroundImage = null;
            button6.BackgroundImage = null;
            button7.BackgroundImage = null;
            button8.BackgroundImage = null;
            button9.BackgroundImage = null;
            button10.BackgroundImage = Properties.Resources.windowsxptile_0000_1;
            button11.BackgroundImage = Properties.Resources.windowsxptile_0001_2;
            button12.BackgroundImage = Properties.Resources.windowsxptile_0002_3;
            button13.BackgroundImage = Properties.Resources.windowsxptile_0003_4;
            button14.BackgroundImage = Properties.Resources.windowsxptile_0004_5;
            button15.BackgroundImage = Properties.Resources.windowsxptile_0005_6;
            button16.BackgroundImage = Properties.Resources.windowsxptile_0006_7;
            button17.BackgroundImage = Properties.Resources.windowsxptile_0007_8;
            button18.BackgroundImage = Properties.Resources.windowsxptile_0008_9;
            // button20.Hide();


        }


        private void button10_Click(object sender, EventArgs e)
        {

            if (button10.BackgroundImage!=null)//sets the selected puzzle piece
                select = 1;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (button11.BackgroundImage != null)
                select = 2;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (button12.BackgroundImage != null)
                select = 3;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (button13.BackgroundImage != null)
                select = 4;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (button14.BackgroundImage != null)
                select = 5;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (button15.BackgroundImage != null)
                select = 6;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (button16.BackgroundImage != null)
                select = 7;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (button17.BackgroundImage != null)
                select = 8;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (button18.BackgroundImage != null)
                select = 9;

        }
        private void getPic(Button MyButton, int select)//sets correct puzzle piece selection according to selected button
        {
            if (select == 1)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0000_1;
                button10.BackgroundImage = null;
            }
            if (select == 2)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0001_2;
                button11.BackgroundImage = null;
            }
            if (select == 3)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0002_3;
                button12.BackgroundImage = null;
            }
            if (select == 4)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0003_4;
                button13.BackgroundImage = null;
            }
            if (select == 5)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0004_5;
                button14.BackgroundImage = null;
            }
            if (select == 6)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0005_6;
                button15.BackgroundImage = null;
            }
            if (select == 7)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0006_7;
                button16.BackgroundImage = null;
            }
            if (select == 8)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0007_8;
                button17.BackgroundImage = null;
            }
            if (select == 9)
            {
                MyButton.BackgroundImage = Properties.Resources.windowsxptile_0008_9;
                button18.BackgroundImage = null;
            }

        }

        private void button19_Click(object sender, EventArgs e)
        {
            resetBoard();
        }
    }
    }
