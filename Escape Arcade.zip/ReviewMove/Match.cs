﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace ReviewMove
{
    public partial class Match : Form
    {
        //SoundPlayer soundPlayer = new SoundPlayer(soundLocation: @"C:\Users\Anton\Downloads\wronganswer-37702");
        Random random = new Random();

        //public static int MatchInt = 0;

        List<string> icons = new List<string>()
        {
            "a","a","b","b","c","c","d","d", "e","e","f","f","g","g","h","h"
        };

        Label firstClicked, secondClicked;
        

        
        public Match()
        {
            InitializeComponent();
            AssignIconsToSquare();
        }

       private void AssignIconsToSquare()
        {
            Label label;
            int ranNum;

            for(int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                if (tableLayoutPanel1.Controls[i] is Label)
                label = (Label)tableLayoutPanel1.Controls[i];
                else
                    continue;

                ranNum = random.Next(0, icons.Count);
                label.Text = icons[ranNum];

                icons.RemoveAt(ranNum);
            }
        }

        private void MatchTimer_Tick(object sender, EventArgs e)
        {
            MatchTimer.Stop();
            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;

            firstClicked = null;
            secondClicked = null;
        }

        private void label_Click(object sender, EventArgs e)
        {
            if (firstClicked != null && secondClicked != null)
                return;
            Label clickedLabel = sender as Label;

            if (clickedLabel == null)
                return;
            if (clickedLabel.ForeColor == Color.Black)
                return;

            if(firstClicked == null)
            {
                firstClicked = clickedLabel;
                firstClicked.ForeColor = Color.Black;
                return;
             }

            secondClicked = clickedLabel;
            secondClicked.ForeColor = Color.Black;
            CheckForWin();

            if (firstClicked.Text == secondClicked.Text)
            {
                firstClicked =null;
                secondClicked = null;

            }
            else
               // soundPlayer.Play();
                MatchTimer.Start();
            
        }

        private void skipmatch_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You Won, A New Door Has Unlocked!");

            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void Match_Load(object sender, EventArgs e)
        {

        }

        private void CheckForWin()
        {
            
            for(int i = 0; i< tableLayoutPanel1.Controls.Count; i++)
            {
                Label label;
                label = tableLayoutPanel1.Controls[i] as Label;
                if (label !=null && label.ForeColor == label.BackColor)
                    //MatchInt = 1;
                return;
            }
            MessageBox.Show("You Won, A New Door Has Unlocked!");
            
            Form1 f1 = new Form1();
            
            f1.Show();
            this.Hide();
            
        }
       
    }
}
