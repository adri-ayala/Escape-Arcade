namespace ReviewMove
{
    public partial class Form1 : Form
    {
        bool moveRight, moveLeft, moveUp, moveDown;
        int speed = 12;
        
      
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //int matchInt = Match.MatchInt;
            //if (matchInt == 1)
            //{

            //    MatchDoor.Hide();
            //}
        }

        private void SimonDoor_Click(object sender, EventArgs e)
        {

        }

        private void Lock_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                moveLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveRight = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                moveDown = true;
            }
            if (e.KeyCode == Keys.Up)
            {
                moveUp = true;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                moveLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveRight = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                moveDown = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                moveUp = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (moveLeft == true && Box.Left > 0)
            {
                Box.Left -= speed;
            }
            if (moveRight == true && Box.Left <650)
            {
                Box.Left += speed;
            }
            if (moveUp == true && Box.Top >0)
            {
                Box.Top -= speed;
            }
            if (moveDown == true && Box.Top < 517)
            {
                Box.Top += speed;
            }
            if (Box.Left <= MatchDoor.Right && MatchDoor.Left <= Box.Right && Box.Top <= MatchDoor.Bottom && MatchDoor.Top <= Box.Bottom)
            {
                Match f2 = new Match();
                f2.Show();
                this.Hide();
                Box.Top = 200;
                Box.Left = 200;

                moveLeft = false;
                moveRight = false;
                moveUp = false;
                moveDown = false;
            }

            if (Box.Left <= ExitDoor.Right && ExitDoor.Left <= Box.Right && Box.Top <= ExitDoor.Bottom && ExitDoor.Top <= Box.Bottom)
                {
                    Exit f5 = new Exit();
                    f5.Show();
                    this.Hide();
                    Box.Top = 200;
                    Box.Left = 200;

                    moveLeft = false;
                    moveRight = false;
                    moveUp = false;
                    moveDown = false;

                }
            if (Box.Left <= SimonDoor.Right && SimonDoor.Left <= Box.Right && Box.Top <= SimonDoor.Bottom && SimonDoor.Top <= Box.Bottom)
            {
                Simon f3 = new Simon();
                f3.Show();
                this.Hide();
                Box.Top = 200;
                Box.Left = 200;

                moveLeft = false;
                moveRight = false;
                moveUp = false;
                moveDown = false;



            }
            if (Box.Left <= PuzzelDoor.Right && PuzzelDoor.Left <= Box.Right && Box.Top <= PuzzelDoor.Bottom && PuzzelDoor.Top <= Box.Bottom)
            {
                Jigsaw f4 = new Jigsaw();
                f4.Show();
                this.Hide();
                Box.Top = 200;
                Box.Left = 200;

                moveLeft = false;
                moveRight = false;
                moveUp = false;
                moveDown = false;



            }

        }
      
        /*internal void reciveDataMatch(bool matchResults)
        {
            bool resultsMatch = matchResults;
        }*/
    }
}