﻿namespace ReviewMove
{
    partial class Exit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Exit));
            this.labelexit = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AgainDoor = new System.Windows.Forms.PictureBox();
            this.Exit2Door = new System.Windows.Forms.PictureBox();
            this.Box = new System.Windows.Forms.PictureBox();
            this.ExitTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.AgainDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit2Door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box)).BeginInit();
            this.SuspendLayout();
            // 
            // labelexit
            // 
            this.labelexit.AutoSize = true;
            this.labelexit.BackColor = System.Drawing.Color.White;
            this.labelexit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelexit.Location = new System.Drawing.Point(126, 152);
            this.labelexit.Name = "labelexit";
            this.labelexit.Size = new System.Drawing.Size(113, 28);
            this.labelexit.TabIndex = 0;
            this.labelexit.Text = "Play Again";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(453, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Exit";
            // 
            // AgainDoor
            // 
            this.AgainDoor.Image = ((System.Drawing.Image)(resources.GetObject("AgainDoor.Image")));
            this.AgainDoor.Location = new System.Drawing.Point(126, 1);
            this.AgainDoor.Name = "AgainDoor";
            this.AgainDoor.Size = new System.Drawing.Size(125, 148);
            this.AgainDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AgainDoor.TabIndex = 2;
            this.AgainDoor.TabStop = false;
            // 
            // Exit2Door
            // 
            this.Exit2Door.Image = ((System.Drawing.Image)(resources.GetObject("Exit2Door.Image")));
            this.Exit2Door.Location = new System.Drawing.Point(412, 1);
            this.Exit2Door.Name = "Exit2Door";
            this.Exit2Door.Size = new System.Drawing.Size(125, 148);
            this.Exit2Door.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Exit2Door.TabIndex = 3;
            this.Exit2Door.TabStop = false;
            // 
            // Box
            // 
            this.Box.BackColor = System.Drawing.Color.LightBlue;
            this.Box.Location = new System.Drawing.Point(315, 214);
            this.Box.Name = "Box";
            this.Box.Size = new System.Drawing.Size(50, 50);
            this.Box.TabIndex = 4;
            this.Box.TabStop = false;
            // 
            // ExitTimer
            // 
            this.ExitTimer.Enabled = true;
            this.ExitTimer.Tick += new System.EventHandler(this.ExitTimer_Tick);
            // 
            // Exit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(682, 353);
            this.Controls.Add(this.Box);
            this.Controls.Add(this.Exit2Door);
            this.Controls.Add(this.AgainDoor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelexit);
            this.Name = "Exit";
            this.Text = "Exit";
            this.Load += new System.EventHandler(this.Exit_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Exit_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Exit_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.AgainDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit2Door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelexit;
        private Label label1;
        private PictureBox AgainDoor;
        private PictureBox Exit2Door;
        private PictureBox Box;
        private System.Windows.Forms.Timer ExitTimer;
    }
}