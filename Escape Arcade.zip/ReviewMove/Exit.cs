﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReviewMove
{
    public partial class Exit : Form
    {
        bool moveRight, moveLeft, moveUp, moveDown;

        int speed = 12;

        public Exit()
        {
            InitializeComponent();
        }

        private void Exit_Load(object sender, EventArgs e)
        {

        }
        private void Exit_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                moveLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveRight = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                moveDown = true;
            }
            if (e.KeyCode == Keys.Up)
            {
                moveUp = true;
            }
        }

        private void Exit_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                moveLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveRight = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                moveDown = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                moveUp = false;
            }
        }

        private void ExitTimer_Tick(object sender, EventArgs e)
        {
            if (moveLeft == true && Box.Left > 0)
            {
                Box.Left -= speed;
            }
            if (moveRight == true && Box.Left <650)
            {
                Box.Left += speed;
            }
            if (moveUp == true && Box.Top >0)
            {
                Box.Top -= speed;
            }
            if (moveDown == true && Box.Top < 517)
            {
                Box.Top += speed;
            }
            if (Box.Left <= AgainDoor.Right && AgainDoor.Left <= Box.Right && Box.Top <= AgainDoor.Bottom && AgainDoor.Top <= Box.Bottom)
            {
                Form1 f1 = new Form1();
                f1.Show();
                this.Hide();
                Box.Top = 200;
                Box.Left = 200;

                moveLeft = false;
                moveRight = false;
                moveUp = false;
                moveDown = false;
            }
        }
    }
}
